import { useRef, useState } from "react"
 
let FunComp3 = ()=>{
    let [ user, accessUser ] = useState({ firstname : "", lastname : "" });
    let fname = useRef('');
    let lname = useRef('');
 
    let changeUserInfo = ()=>{
        if(fname.current.value && lname.current.value){
            accessUser({
                 firstname : fname.current.value,
                 lastname : lname.current.value
            })
        }else{
            alert("you must provide both the input values")
        }
    }
    return <div>
                <h1>Function Component Object Hook</h1>
                <h2>User Firstname :  { user.firstname }</h2>
                <h2>User Lastname :  { user.lastname }</h2>
                <hr />
                <ul>
                    <li>First Name { user.firstname }</li>
                    <li>Last Name { user.lastname }</li>
                </ul>
                <label>User First Name : <input ref={ fname } type="text" /> </label>
                <br />
                <label>User Last Name : <input ref={ lname } type="text" /> </label>
                {/* <button onClick={()=>{ accessUser({ ...user, firstname : 'Tony' }) }}>Change First Name</button>
                <button onClick={()=>{ accessUser({ ...user, lastname : 'Stark' }) }}>Change Last Name</button> */}
                <br />
                <button onClick={()=>{ changeUserInfo() }}>Change User Name</button>
            </div>
}
 
export default FunComp3;