import { useState } from "react"

function FunComp(){
    // console.log( useState(0) );
    let [ power, accessPower ] = useState(0);
    return <div>
        <h1>Function Component</h1>
        <h2>Power : { power }</h2>
        <button onClick={()=>{ accessPower(power+1) }}>Increase Power</button>
    </div>
}

export default FunComp;