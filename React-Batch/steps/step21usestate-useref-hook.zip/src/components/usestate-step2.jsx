import { useState } from "react"
 
let FunComp2 = ()=>{
    // let [ user, accessUser ] = useState({ username : "", userage : 0 });
 
    let [ username, accessUserName ] = useState("");
    let [ userage, accessUserAge ] = useState(0);
 
    return <div>
                <h1>Function Component Object Hook</h1>
                <h2>User Name :  { username }</h2>
                <h2>User Age :  { userage }</h2>
                {/* <button onClick={()=>{ accessUser({ username : 'Bruce', userage : 21 }) }}>Update User</button> */}
                <button onClick={()=>{ accessUserName('Bruce'); accessUserAge(21)  }}>Update User</button>
            </div>
}
 
export default FunComp2;