import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import ChildComp from './components/classcomp';
import FunComp from './components/funcomp';
import FunComp3 from './components/usestate-step3';
import FunComp2 from './components/usestate-step2';

 
class MainApp extends Component{
 
  render(){
    return <div className="container">
            <h1>Welcome to your life</h1>
           <h1>Hooks</h1>
           <hr/>
           <ChildComp/>
           <hr/>
           <FunComp/>
           <hr/>
           <FunComp2/>
           <hr/>
           <FunComp3/>
           </div>
  }
};
 
ReactDOM.render(<MainApp/>,  document.getElementById('root') );
 