import { useSelector, useDispatch } from 'react-redux'
import addHero from "../redux/index";

function HeroHookComp(){
    // const numberOfHeroes = useSelector( (store )=>{ return store.numberOfHeroes });
    const numberOfHeroes = useSelector( store =>store.numberOfHeroes );
    const dispatch = useDispatch();
    return <div>
            <h1>Hook Component | Avenger's Enrollment Program</h1>
            <h2>Number of Avengers Selected : { numberOfHeroes }</h2>
            <button onClick={ ()=>{ dispatch( addHero() ) } }>Add Avenger</button>
        </div>
}

export default HeroHookComp;