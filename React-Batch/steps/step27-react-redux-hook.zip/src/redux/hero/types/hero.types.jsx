const ADD_HERO = "ADD_HERO";

export default ADD_HERO;