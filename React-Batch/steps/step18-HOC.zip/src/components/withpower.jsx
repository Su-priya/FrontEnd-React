import React,{ Component } from "react";

let WithPower = (OriginalComponent)=>{
    class TempComp extends Component{
        state = {
            power : 0
        }
        increasePower = ()=>{
            this.setState(function(existingState){
                return {
                    power : existingState.power + 1
                }
            })
        }
        render(){
            return <OriginalComponent incPower={ this.increasePower }
            power={ this.state.power }            
            title="Hello from HOC"/>; 
        }
    }
    return TempComp;
};

export {WithPower};