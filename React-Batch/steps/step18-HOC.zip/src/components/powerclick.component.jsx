import React,{ Component } from "react";
import { WithPower } from "./withpower";
 
class PowerClickComp extends Component{
    
    render(){
        return <div>
                <h1>Power Click Component</h1>
                <h2>Title : {this.props.title} </h2>
                <button onClick={ this.props.incPower }>Increase Power</button>
                <h2>Power : { this.props.power }</h2>
            </div>
    }
}
 
// export default PowerClickComp;
export default WithPower(PowerClickComp);