import React,{ Component } from "react";
import { WithPower } from "./withpower";
 
class PowerDragComp extends Component{
   
    render(){
        return <div>
                <h1>Power Drag Component</h1>
                <h2>Title : {this.props.title} </h2>
                <div style={ { width : "200px" , 
                               height : "50px", 
                               backgroundColor : "crimson", 
                               fontFamily : "arial", 
                               fontWeight : "bold", 
                               textAlign : "center", 
                               lineHeight : "50px", 
                               color : "papayawhip"}} 
                               onMouseMove={ this.props.incPower }>Increase Power</div>
                <h2>Power : { this.props.power }</h2>
            </div>
    }
}
 
export default WithPower(PowerDragComp);