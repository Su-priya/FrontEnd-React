import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import PowerClickComp from './components/powerclick.component';
import PowerDragComp from './components/powerdrag.component';
class MainApp extends Component{
  render(){
    return <div className="container">
            <h1>Welcome to your life</h1>
            <PowerClickComp/>
            <hr/>
            <PowerDragComp/>
           </div>
  }
};
ReactDOM.render(<MainApp/>,  document.getElementById('root') );