import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class PopUpComp extends Component{
  render(){
    return ReactDOM.createPortal(this.props.children,
      document.getElementById('popup'))        
  }
};

class MainApp extends Component{
  state = {
    show : false
  }
  showHidePopUp = ()=>{
    this.setState({show : !this.state.show})
  }

  render(){
    return <div className="container">
            <h1>Welcome to your life</h1>
            { this.state.show ? <PopUpComp>
              <div>
              <h2>Terms and Conditions</h2>
              <hr/>
              <p>
              Lorem, ipsum dolor sit amet consectetur adipisicing elit. In, dolores quas excepturi delectus cumque debitis iusto laboriosam, minima incidunt dolorum animi doloremque similique nemo, alias deserunt labore aliquid vitae cum?
              </p>
              <button onClick={ this.showHidePopUp }>Hide</button>
           </div>
           </PopUpComp> : <button onClick={ this.showHidePopUp }>Show</button>}
           </div>
  }
};
ReactDOM.render(<MainApp/>,  document.getElementById('root') );