import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import HeroComp from './components/hero.component';
import { Provider} from "react-redux";
import store from './redux/store';

class MainApp extends Component{
  render(){
    return <div className="container">
           <h1>React Redux Application</h1>
           <Provider store={ store }>
           <HeroComp/>   
           </Provider>        
           </div>
  }
};

ReactDOM.render(<MainApp/>,  document.getElementById('root') );