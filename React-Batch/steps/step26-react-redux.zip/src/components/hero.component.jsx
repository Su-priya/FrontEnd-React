import { Component } from "react";
import addHero from "../redux/index"
import { connect } from "react-redux";

class HeroComp extends Component{
    render(){
        return <div>
            <h1>Avenger's Enrollment Program</h1>
            <h2>Number of Avengers Selected : { this.props.numberOfHeroes }</h2>
            <button onClick={ this.props.addHero }>Add Avenger</button>
        </div>
    }
}
const mapStateToProps = (state)=>{
    return {
        numberOfHeroes : state.numberOfHeroes
    }
}
const mapDispatchToProps = (dispatch)=>{
    return {
       addHero : ()=> { dispatch(addHero()) }
    }
}
/* 
let tempComp = connect(mapStateToProps, mapDispatchToProps)
tempComp(HeroComp);
export default HeroComp ; 
*/
export default connect(mapStateToProps, mapDispatchToProps)(HeroComp);