import React, { Component } from "react";
 
class ChildComp extends Component{
    render(){
        return <div>
                    <h1>Child Component</h1>
                    <h2>Power is : { this.props.boost }</h2>
                    <input type="range" onClick={(evt)=>{this.props.addPower(evt.target.value)}}/>
               </div>
    }
}
export default ChildComp;