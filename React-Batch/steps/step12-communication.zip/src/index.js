import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import ChildComp from './components/child.component';
 
class MainApp extends Component{
  state = {
    power : 0
  }
  increasePower = (evt)=>{
     this.setState({
               power : Number( evt.target.value )
      });
  }
  setPower = (val)=>{
    this.setState({
      power : val
    });
  }
    
  render(){
    return <div className="container">
            <h1>Welcome to your life | { this.state.power }</h1>
            <input value={ this.state.power } min="0" max="10" type="range" onInput={ (evt)=>{ this.increasePower(evt) } }/>
            <ChildComp addPower={ this.setPower } boost={ this.state.power } />
           </div>
  }
};
 
ReactDOM.render(<MainApp/>,  document.getElementById('root') );
 