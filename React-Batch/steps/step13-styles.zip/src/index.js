import React, { Component } from 'react';
import ReactDOM  from 'react-dom';
// import boxer from './config.jsx';
import client from './clientstyle.module.css';
import './mystyle.css';

class MainApp extends Component{
    render(){
        return <div className="container">
            <h1>Welcome to your life</h1>
            <section className="box">
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nisi, debitis repudiandae amet nemo consequatur blanditiis ratione dicta quasi ipsam. Unde odio laudantium pariatur. Natus, consectetur nihil? Quibusdam quod recusandae fugiat!
            </section>
            <section className={client.box}>
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nisi, debitis repudiandae amet nemo consequatur blanditiis ratione dicta quasi ipsam. Unde odio laudantium pariatur. Natus, consectetur nihil? Quibusdam quod recusandae fugiat!
            </section>
            <section className="box">
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nisi, debitis repudiandae amet nemo consequatur blanditiis ratione dicta quasi ipsam. Unde odio laudantium pariatur. Natus, consectetur nihil? Quibusdam quod recusandae fugiat!
            </section>
        </div>
    }
};

ReactDOM.render(<MainApp/>, document.getElementById('root'));