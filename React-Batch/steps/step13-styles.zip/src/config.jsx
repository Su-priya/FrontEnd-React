let boxer = {
    fontFamily : 'arial',
    margin : '10px',
    textAlign: 'justify',
    width : '200px',
    backgroundColor : 'darkslateblue',
    color : 'papayawhip',
    padding : '10px',
    boxSizing : 'border-box',
    float : 'left'

}

export default boxer; 