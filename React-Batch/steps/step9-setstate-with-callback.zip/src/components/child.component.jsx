import React, { Component } from "react";
 
class ChildComp extends Component{
    state = {
        power : 0,
        message : ""
    };
    increasePower = (evt)=>{
 /*       this.setState({
           power : this.state.power + 1
        });
        console.log(this.state.power);  */
        this.setState({power:evt.target.value},function(){
            // console.log(this.state.power);
            if(this.state.power<5){
                this.setState({
                    message : " Hero is Weak "
                })
            }else{
                this.setState({
                    message : " Hero is Strong "
                })

            }
        });
    }
    render(){
        return <div>
                    <h1>Child Component</h1>
                    <h2>Power : { this.state.power }|{ this.state.message }</h2>
                    {/* <button onClick={ this.increasePower }>Increase Power</button> */}
                    <input min="0" max="10" type="range" onInput={(evt)=>{this.increasePower(evt)}}/>
               </div>
    }
}
export default ChildComp;