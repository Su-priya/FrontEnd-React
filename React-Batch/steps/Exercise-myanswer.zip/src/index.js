import ReactDOM from 'react-dom';
import React, { Component } from 'react';

class MainApp extends Component{
  render(){
    return <>
    <div className="box">
    <h3>APP (component)</h3>
    <header style={{backgroundColor:"yellow"}}>HEADER (component)</header>
    <main style={{backgroundColor:"orange"}}>MAIN (component)
    <article>ARTICLE (component)</article>
    <article>ARTICLE component</article>
    </main>
    
    <footer style={{backgroundColor:"yellow"}}>FOOTER (component)</footer>
    </div>
    </>
  }
}
ReactDOM.render(<MainApp/>,  document.getElementById('root') );
 
