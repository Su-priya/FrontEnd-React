import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import ChildComp from './components/child.component';
 
class MainApp extends Component{
  render(){
    return <div className="container">
            <h1>Welcome to your life</h1>
            <ChildComp boost={ 5 }/>
           </div>
  }
};
 
ReactDOM.render(<MainApp/>,  document.getElementById('root') );