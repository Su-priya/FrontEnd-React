import React from 'react';

let VersionContext = React.createContext();


/*let VersionProvider = VersionContext.Provider;
let VersionConsumer = VersionContext.Consumer;
export { VersionConsumer, VersionProvider };
*/

export default VersionContext;
