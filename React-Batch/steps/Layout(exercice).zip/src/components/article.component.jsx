import { Component } from 'react';
class ArticleComp extends Component{
    render(){
        return <article>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis ullam, possimus itaque culpa ipsum beatae rerum a at dignissimos facere porro velit quae quos natus tenetur excepturi earum, facilis iste.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus tempore nostrum voluptates dignissimos sed ex, beatae architecto accusantium quam ut natus, est atque assumenda quisquam adipisci inventore enim molestias nesciunt.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit rem culpa modi reprehenderit doloremque ut nemo tempore? Laudantium atque quam praesentium, corporis quis, impedit error voluptate nemo nisi neque quasi.
        </article>
    }
}

export default ArticleComp;