import { Component } from 'react';
class FooterComp extends Component{
    render(){
        return <footer>
                    &copy; copyrights reserved by IBM India
               </footer>
    }
}

export default FooterComp;