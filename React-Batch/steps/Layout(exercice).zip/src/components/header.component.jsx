import { Component } from 'react';
class HeaderComp extends Component{
    render(){
        return <header>
                   <h1> Welcome to IBM India </h1>
               </header>
    }
}

export default HeaderComp;