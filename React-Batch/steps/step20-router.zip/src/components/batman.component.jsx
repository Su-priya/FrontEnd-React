import React,{ Component } from "react";

class BatmanComp extends Component{
    render(){
        return <h1>Batman Component</h1>
    }
}

export default BatmanComp;