import React,{ Component } from "react";

class WonderwomanComp extends Component{
    render(){
        return <h1>Wonderwoman Component</h1>
    }
}

export default WonderwomanComp;