import React,{ Component } from "react";

class AquamanComp extends Component{
    render(){
        return <h1>Aquaman Component</h1>
    }
}

export default AquamanComp;