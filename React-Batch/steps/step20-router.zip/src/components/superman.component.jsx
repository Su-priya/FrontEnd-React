import { Component } from "react";
 
class SupermanComp extends Component{
    render(){
        return <div>
            <h1>Superman Component</h1>
            <h2>Quantity : { this.props.match.params.qty || '0'}</h2>
        </div>
    }
}
 
export default SupermanComp;
 