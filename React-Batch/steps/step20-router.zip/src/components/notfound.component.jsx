import React,{ Component } from "react";

class NotfoundComp extends Component{
    render(){
        return <h1>Notfound Component</h1>
    }
}

export default NotfoundComp;