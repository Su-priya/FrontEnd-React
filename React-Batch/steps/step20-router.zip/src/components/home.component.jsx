import React,{ Component } from "react";

class HomeComp extends Component{
    render(){
        return <h1>Wonderwoman Component</h1>
    }
}

export default HomeComp;