import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Link, Route, Switch, NavLink } from 'react-router-dom';
import AquamanComp from './components/aquaman.component';
import BatmanComp from './components/batman.component';
import HomeComp from './components/home.component';
import SupermanComp from './components/superman.component';
import WonderWomanComp from './components/wonderwoman.component';
import NotFoundComp from './components/notfound.component';
import "./routerstyle.css";
 
class MainApp extends Component{
  state = {
    quantity : 0
  }
  changeQuantity = (evt)=>{
    this.setState({ quantity : Number( evt.target.value ) })
  }
  render(){
    return <div className="container">
            <h1>Welcome to your life</h1>
            <input type="range" value={ this.state.quantity } onInput={ this.changeQuantity } />
            { this.state.quantity }
            <hr/>
            <BrowserRouter>
              {/* <ul>
                <li><a href="/">Home</a></li>
                <li><a href="/batman">Batman</a></li>
                <li><a href="/superman">Superman</a></li>
                <li><a href="/aquaman">Aquaman</a></li>
                <li><a href="/wonderwomen">Wonder Women</a></li>
                <li><a href="/ironman">Ironman</a></li>
              </ul> */}
              {/* <ul>
                <li><Link to="/">Home</Link></li>
                <li><Link to="/batman">Batman</Link></li>
                <li><Link to="/superman">Superman</Link></li>
                <li><Link to="/aquaman">Aquaman</Link></li>
                <li><Link to="/wonderwomen">Wonder Women</Link></li>
                <li><Link to="/ironman">Ironman</Link></li>
              </ul> */}
              <ul>
                <li><NavLink activeClassName="boxer" to="/" exact>Home</NavLink></li>
                <li><NavLink activeClassName="boxer" to="/batman">Batman</NavLink></li>
                <li><NavLink activeClassName="boxer" to={ "/superman/"+this.state.quantity }>Superman</NavLink></li>
                <li><NavLink activeClassName="boxer" to="/aquaman">Aquaman</NavLink></li>
                <li><NavLink activeClassName="boxer" to="/wonderwomen">Wonder Women</NavLink></li>
                <li><NavLink activeClassName="boxer" to="/ironman">Ironman</NavLink></li>
              </ul>
              <Switch>
                <Route path="/" exact>
                  <HomeComp/>
                </Route>
                <Route path="/batman" component={ BatmanComp }/>
                <Route path="/superman/:qty" component={ SupermanComp }/>
                <Route path="/aquaman" component={ AquamanComp }/>
                <Route path="/wonderwomen" component={ WonderWomanComp }/>
                <Route component={ NotFoundComp }/>
              </Switch>
            </BrowserRouter>
           </div>
  }
};
 
ReactDOM.render(<MainApp/>,  document.getElementById('root') );
 