import React, { Component, useState } from 'react';
import ReactDOM from 'react-dom';
import ChildComp from './components/child.component';
 
let MainApp = function(){
  let [state, setState] = useState({ power : 0, version : 0 });
 
  let increasePower = ()=>{
    setState({
      ...state,
      power : state.power + 1
     
    })
  };
  let changeVersion = ()=>{
    setState({
      ...state,
      version : Math.round(Math.random() * 1000)
    })
  };
 
  return <div className="container">
            <h1>Use Effect Hook</h1>
            <button onClick={ increasePower }>Increase Power </button>
            <button onClick={ changeVersion }>Change Version </button>
            <hr/>
            {
              state.power < 10 ?  <ChildComp ver={ state.version } pow={ state.power }/> : <h1>Component Removed</h1>
            }
           </div>
};
 
ReactDOM.render(<MainApp/>,  document.getElementById('root') );
