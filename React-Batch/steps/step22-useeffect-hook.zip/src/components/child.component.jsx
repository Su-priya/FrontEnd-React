import { useEffect } from "react";
 
function ChildComp({ pow, ver }){
 
    useEffect(function(){
        console.log("component mounted");
    },[]);
 
    useEffect(function(){
        console.log("component's power is updated", pow);
    },[pow]);
 
    useEffect(function(){
        return function(){
            console.log("component unmounted");
        }
    },[])
 
 
    return <div>
                <h1>Child Component</h1>
                <h2>Power is : { pow }</h2>
                <h2>Version is : { ver }</h2>
           </div>
}
 
export default ChildComp;