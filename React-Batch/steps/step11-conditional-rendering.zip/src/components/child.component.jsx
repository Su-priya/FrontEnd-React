import React, { Component } from "react";
 
class ChildComp extends Component{
    state = {
        power : 4
    };
    render(){
        /* if(this.state.power < 5){
            return <div>
                        <h1>Power is less than 5</h1>
                        <h2>Power : { this.state.power } </h2>
                   </div>
        }else{
            return <div>
                        <h1>Power is more than 5</h1>
                        <h2>Power : { this.state.power } </h2>
                    </div>
        } */
 
        return <div>
                    <input value={ this.state.power } type="range" min="0" max="10" onInput={ (evt)=>{
                        this.setState({
                            power : evt.target.value
                        })
                    }}/>
                    { this.state.power > 5 ? <h1>Power is more than 5</h1> : <h1>Power is less than 5</h1> }
                    { this.state.power < 5 && <h1> Power is less than 5 </h1>}
                    <h2>Power : { this.state.power } </h2>
                </div>
    }
}
export default ChildComp;