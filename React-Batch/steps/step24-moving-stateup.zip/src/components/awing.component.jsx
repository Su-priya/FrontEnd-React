import { Component } from "react";
import Block1Comp from "./block1.component";
import Block2Comp from "./block2.component";

class AWingComp extends Component{
   /*state = {
        version : 0
    }
    componentDidMount(){
        setInterval(()=>{
            this.setState({
                version : Math.round(Math.random() * 1000)
            })
        }, 4000)
    } */
    render(){
        return <div style={ { border : '2px solid grey', padding : '10px', width : '600px', margin : '10px', float : 'left' }}>
            <h1>A Wing Component</h1>
            <hr/>
            <Block1Comp ver={this.props.ver}></Block1Comp>
            <Block2Comp ver={this.props.ver}></Block2Comp>
        </div>
    }
}

export default AWingComp;